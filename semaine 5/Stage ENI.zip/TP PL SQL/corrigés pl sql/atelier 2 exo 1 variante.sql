set serveroutput on
declare 
-- r�organisation des activit�s
-- il est d�cid�, pour les ateliers qui ont plus de 2 activit�s
-- de supprimer leurs activit�s qui n'ont pas d'incrits.
--
  cursor c_act is select c.no_atel,c.jour,c.rowid 
    from inscription s, activite c
    where exists (select no_atel from activite e 
                   where c.no_atel=e.no_atel 
                   group by no_atel having count(*)>2
                  )
    and c.no_atel=s.no_atel (+)
    and c.jour=s.jour (+)
    and no_insc is null;
  cpt binary_integer :=0;
begin
    for v_act in c_act loop
      dbms_output.put_line (v_act.no_atel||','||v_act.jour);
      delete from activite where rowid=v_act.rowid;
      cpt := cpt+sql%rowcount;
    end loop;
  dbms_output.put_line('nombre d''activit�s supprim�es : '||cpt);
  commit;
end;
/