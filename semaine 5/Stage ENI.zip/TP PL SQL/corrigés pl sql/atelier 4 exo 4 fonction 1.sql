create or replace function inscrits_activite 
  (Patel atelier.intitule%type,Pjour activite.jour%type) 
  return number
  is
   retour number;
    msg_erreur varchar2(200);
  begin
    select count(*) into retour
      from atelier t, inscription s
      where intitule=upper(Patel)
      and jour=upper(Pjour)
      and s.no_atel=t.no_atel;
    if retour=0 then
      msg_erreur := 'l''activit� '||patel||' - '||pjour||
                   ' n''existe pas ou n''a pas d''inscrits';
      raise_application_error (-20102,msg_erreur);
    else
      return retour;
    end if;
   end;
/
