create or replace trigger tr_ins_v_anim
instead of insert
on v_animation
for each row
begin
  insert into animateur (no_anim,nom,prenom,tel)
    values (:new.no_anim,:new.nom,:new.prenom,:new.tel);
  insert into atelier (no_atel,intitule,genre,vente_heure,no_anim)
    values (:new.no_atel,:new.intitule,:new.genre,:new.vente_heure,:new.no_anim);
end;
/
