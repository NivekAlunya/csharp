create or replace function age_ville 
  (Pville adherent.ville%type) 
  return number
  is
   retour number;
    msg_erreur varchar2(200);
  begin
    select avg(years_between(sysdate,date_naissance)) into retour
      from adherent
      where ville=upper(Pville);
    if retour=0 then
      msg_erreur := 'la ville '||pville||' n''existe pas dans la base';
      raise_application_error (-20103,msg_erreur);
    else
      return round(retour,2);
    end if;
   end;
/
