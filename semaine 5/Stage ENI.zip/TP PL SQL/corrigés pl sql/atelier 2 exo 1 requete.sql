delete from activite a where exists (select 1 from (select c.no_atel,c.jour 
    from inscription s, activite c
    where exists (select no_atel from activite e 
                   where c.no_atel=e.no_atel 
                   group by no_atel having count(*)>2
                  )
    and c.no_atel=s.no_atel (+)
    and c.jour=s.jour (+)
    and no_insc is null) d
    where a.no_atel=d.no_atel
    and a.jour=d.jour);
rollback;    
    

