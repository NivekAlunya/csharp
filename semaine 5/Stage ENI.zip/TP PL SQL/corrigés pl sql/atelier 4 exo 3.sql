create or replace function years_between (date1 in date,date2 in date) 
  return number
  is
  retour number;
  MsgErr varchar2(100);
  begin
    if date2 > date1 then
      MsgErr := 'La premi�re date est ant�rieure � la deuxi�me date'�;
      raise_application_error (-20101,MsgErr);
    end if;
    retour := floor(months_between(date1,date2)/12);
    return retour;
  end;
/
