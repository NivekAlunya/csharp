set serveroutput on
declare
    type t_c_stat is ref cursor;
  c_stats t_c_stat;
  total number;
  procedure affichage (p_stats in t_c_stat,colonne1 in varchar2,colonne2 in varchar2)
    is
      type t_designation is table of varchar2(35)
        index by binary_integer;
      type t_resultat is table of number
        index by binary_integer;
      designations t_designation;
      resultats t_resultat;  
    begin
      fetch p_stats bulk collect into designations, resultats;
      dbms_output.put_line(chr(13));
      dbms_output.put_line (rpad(colonne1,37)||lpad(colonne2,20));
      dbms_output.put_line (rpad('-',35,'-')||'  '||lpad('-',20,'-'));
      for i in designations.first..designations.last loop
         dbms_output.put_line (rpad(designations(i),37)||
           lpad(round((resultats(i)/total)*100,2),19)||'%');
      end loop;
    end;
begin
  dbms_output.put_line('Statistiques de l''association : les adh�rents');
  dbms_output.put_line(chr(13));
  select count(*) into total from adherent;
  open c_stats for
    select Ville,count(*) as nombre
      from adherent 
      group by ville;
  affichage (c_stats,'Ville','Adh�rents');
  close c_stats;
  open c_stats for
    select sexe,count(*) as nombre
      from adherent 
      group by sexe;
  affichage (c_stats,'Sexe','Adh�rents');
  close c_stats;
  open c_stats for
    select trunc(to_number(to_char(date_naissance,'yy')),-1),count(*) as nombre
      from adherent 
      group by trunc(to_number(to_char(date_naissance,'yy')),-1);
  affichage (c_stats,'Ann�es','Adh�rents');
  close c_stats;
end;
/
