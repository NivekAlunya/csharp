create or replace trigger tr_ui_insc
  before insert or update of no_adher,no_atel
  on inscription
  for each row
  when (new.no_atel=9)
declare
  vAge number(3);
  vNom adherent.nom%type;
  vPrenom adherent.prenom%type;
  MsgErr varchar2(200);
begin
  select nom,prenom,floor(months_between(sysdate,date_naissance)/12)
    into vNom,vPrenom,vAge
    from adherent
    where no_adher=:new.no_adher;
  if vAge < 18 then
    MsgErr := 'l''adh�rent '||vPrenom||' '||vNom||' n''a pas';
    MsgErr := MsgErr||' l''age requis pour participer � l''atelier Escrime M�di�val';
    raise_application_error (-20100,MsgErr);
  end if;
end;
/
show errors
    