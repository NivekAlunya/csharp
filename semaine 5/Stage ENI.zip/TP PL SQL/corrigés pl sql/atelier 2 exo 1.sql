set serveroutput on
declare 
-- r�organisation des activit�s
-- il est d�cid�, pour les ateliers qui ont plus de 2 activit�s
-- de supprimer leurs activit�s qui n'ont pas d'incrits.
--
  cursor c_ate is select no_atel from activite
                   group by no_atel 
                   having count(*)>2;
  cursor c_act (patel number) is select c.no_atel,c.jour,c.rowid 
    from inscription s, activite c
    where c.no_atel=s.no_atel (+)
    and c.jour=s.jour (+)
    and c.no_atel=patel
    and no_insc is null;
  cpt binary_integer :=0;
begin
  for v_ate in c_ate loop
    for v_act in c_act (v_ate.no_atel) loop
      dbms_output.put_line (v_act.no_atel||','||v_act.jour);
      delete from activite where rowid=v_act.rowid;
      cpt := cpt+sql%rowcount;
    end loop;
  end loop;
  dbms_output.put_line('nombre d''activit�s supprim�es : '||cpt);
  commit;
end;
/
