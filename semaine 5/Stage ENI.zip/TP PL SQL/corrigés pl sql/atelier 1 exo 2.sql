variable vnom varchar2(51)
declare
-- recherche de l'adh�rent le plus jeune de la ville de nantes
  maxdate date;
begin
  select max(date_naissance) into maxdate
    from adherent
    where ville='NANTES';
  select prenom||' '||nom into :vnom
    from adherent 
    where date_naissance=maxdate
    and ville= 'NANTES';
end;
/
print vnom