set serveroutput on
declare
  inscrits number;
  intitules atelier.intitule%type;
begin
  for i in 1..16 loop
    select intitule,count(*) into intitules,inscrits
      from inscription s,atelier t
      where s.no_atel=i
      and s.no_atel=t.no_atel
      group by intitule;
    dbms_output.put_line (rpad(intitules,35,'.')||inscrits);
  end loop;
end;
/    
  