create or replace trigger tr_suppr_anim
after delete
on animateur
for each row
BEGIN 
insert into anc_anim
  values (:old.nom,:old.prenom,:old.tel,user);
end;
/
