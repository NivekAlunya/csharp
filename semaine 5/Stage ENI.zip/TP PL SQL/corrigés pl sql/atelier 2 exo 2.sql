connect stag5/abc
set serveroutput on
declare 
-- r�organisation des activit�s
-- il est d�cid�, pour les activit�s du dimanche de reporter leurs inscriptions
-- dans l'activt� du m�me atelier qui a le moins d'inscrits et
-- de supprimer ces activit�s du dimanche.
--
  cursor c_ate is select no_insc,i.no_atel,i.jour from activite c, inscription i
                   where i.jour='DI'
                   and i.no_atel=c.no_atel
                   and i.jour=c.jour
                   for update of i.no_atel,i.jour;
  cursor c_act (p_atel number) is select c.no_atel,c.jour,count(no_insc) nbre
                   from inscription i, activite c
                   where c.no_atel=p_atel
                   and c.jour != 'DI'
                   and c.jour=i.jour (+)
                   and c.no_atel=i.no_atel (+)
                   group by c.no_atel,c.jour
                   order by nbre;
  v_act c_act%rowtype;
  
begin
  for v_ate in c_ate loop
    open c_act(v_ate.no_atel);
    fetch c_act into v_act;
    dbms_output.put_line(v_ate.no_insc||','||v_ate.no_atel||','||v_ate.jour);
    update inscription set no_atel=v_act.no_atel,jour=v_act.jour
      where current of c_ate;
      dbms_output.put_line(v_ate.no_insc||','||v_act.no_atel||','||v_act.jour);
    close c_act;
  end loop;
    delete from activite where jour='DI';
    dbms_output.put_line('nombre suppression : '||sql%rowcount);
    comit;
end;
/