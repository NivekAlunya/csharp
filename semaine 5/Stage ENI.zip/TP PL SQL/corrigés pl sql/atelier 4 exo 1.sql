create or replace procedure cre_fact(p_adh number)
is
  Vno_fact number(6);
  V_total number(8,2);
  v_adh adherent%rowtype;
  cursor c_detail  is 
    select d.no_atel,intitule,d.jour,d.duree qte,
           d.vente_heure Prix,d.montant
      from detail d, atelier t
      where d.no_atel=t.no_atel;
begin
--  delete from facture;
--  delete from detail;
  select distinct nom,prenom into v_adh.nom,v_adh.prenom
    from adherent a, inscription i
    where i.no_adher=p_adh
    and a.no_adher=i.no_adher;
  select s_fact.nextval into Vno_fact from sys.dual;
  insert into facture values (Vno_fact,p_adh,null);
  insert into detail
    select Vno_fact,c.no_atel,c.jour,duree,vente_heure,
      duree*vente_heure as montant
      from  inscription s,activite c, atelier t
      where s.no_adher=p_adh
      and s.no_atel=c.no_atel
      and s.jour=c.jour
      and c.no_atel=t.no_atel;
  Update facture f set total=(select sum(montant) from detail d
                               where f.no_fact=d.no_fact); 
  select * into v_adh from adherent where no_adher=p_adh; 
  select total into v_total from facture;
  dbms_output.put_line ('Facture n� '||Vno_fact);
  dbms_output.put(chr(13));
  dbms_output.put_line ('le '||to_char(sysdate,'dd/mm/yyyy'));
  dbms_output.put(chr(13));
  dbms_output.put_line (v_adh.prenom||' '||v_adh.nom);
  dbms_output.put_line (v_adh.rue);
  dbms_output.put(chr(13));
  dbms_output.put_line (v_adh.cp||' '||v_adh.ville);
  dbms_output.put(chr(13));
  dbms_output.put(rpad('n�',6)||rpad('intitule',30)||rpad('qte',6));
  dbms_output.put_line(rpad('Prix',6)||lpad('Montant',15));
  dbms_output.put(chr(13));
  for v in c_detail loop
    dbms_output.put(rpad(v.no_atel,6)||rpad(v.intitule,30)||rpad(v.qte,6));
    dbms_output.put_line(rpad(v.Prix,6)||lpad(v.Montant,15));
  end loop;
  dbms_output.put(chr(13));
  dbms_output.put_line(rpad('Total   ',48,'.')||lpad(v_total,15));
  commit;
exception
  when no_data_found then
    dbms_output.put_line ('L''adh�rent '||v_adh.prenom||' '||v_adh.nom||' n''a pas d''inscription');
  when others then
    dbms_output.put_line (sqlerrm);
end;
/

