set serveroutput on
declare
  -- augmentation du cout heure des animateurs en fonction des r�gles de
  -- gestion suivantes :
  -- Directeur : taux=1%
  -- cadre , addition des taux de la fa�on suivante
  --      si reponsable de plus de 3 animateurs : taux=2% sinon taux=1%
  --      si anime un atelier taux=1% sinon 0%
  -- Agent, si anime 1 atelier taux=2% sinon taux=0%
  --
  -- deuxi�me version
  taux number(5,2);
  result animateur.cout_heure%type:=0;
  nbre number;
  cursor c_ani is select no_anim, fonction, cout_heure
    from animateur for update of cout_heure;
begin
  for v_ani in c_ani loop
    taux := 1;
    if v_ani.fonction='Directeur' then
      taux := taux + 0.01;
    elsif v_ani.fonction='Cadre' then
      begin
        select no_resp into nbre
         from animateur
         where no_resp=v_ani.no_anim
         group by no_resp
          having count(*)>3;
        taux := taux + 0.02;
      exception
        when no_data_found then
        taux := taux + 0.01;
      end;
      begin
        select  no_atel into nbre from atelier
          where no_anim=v_ani.no_anim
          and rownum<2;
        taux := taux + 0.02;
      exception
        when no_data_found then
        null;
      end;
    else
      begin
        select no_atel into nbre from atelier
          where no_anim=v_ani.no_anim
          and rownum<2;
        taux := taux + 0.02;
      exception
        when no_data_found then
        null;
      end;
    end if;
    result := v_ani.cout_heure * taux;
    update animateur set cout_heure= result
      where current of c_ani;
    dbms_output.put (v_ani.no_anim||'-'||v_ani.fonction||'-');
    dbms_output.put_line(taux||'-'||v_ani.cout_heure||'-'||result);
  end loop;
  commit;
end;
/

  