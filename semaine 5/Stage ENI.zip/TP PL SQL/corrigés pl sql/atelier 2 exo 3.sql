declare
  -- augmentation du cout heure des animateurs en fonction des r�gles de
  -- gestion suivantes :
  -- Directeur : taux=1%
  -- cadre , addition des taux de la fa�on suivante
  --      si reponsable de plus de 3 animateurs : taux=2% sinon taux=1%
  --      si anime un atelier taux=1% sinon 0%
  -- Agent, si anime 1 atelier taux=2% sinon taux=0%
  --
  nb_atel number(2);
  nb_anim number(2);
  taux number(5,2);
  result animateur.cout_heure%type:=0;
  cursor c_ani is select no_anim, fonction, cout_heure
    from animateur for update of cout_heure;
begin
  for v_ani in c_ani loop
    taux := 1;
    nb_anim :=0;
    nb_atel :=0;
    if v_ani.fonction='Directeur' then
      taux := taux + 0.01;
    elsif v_ani.fonction='Cadre' then
      select count(*) into nb_anim
        from animateur
        where no_resp=v_ani.no_anim;
      if nb_anim > 3 then
        taux := taux + 0.02;
      else
        taux := taux + 0.01;
      end if;
      select count(*) into nb_atel from atelier
        where no_anim=v_ani.no_anim;
      if nb_atel > 0 then
        taux := taux + 0.01;
      end if;
    else
      select count(*) into nb_atel from atelier
        where no_anim=v_ani.no_anim;
      if nb_atel > 0 then
        taux := taux + 0.02;
      end if;
    end if;
    result := v_ani.cout_heure * taux;
    update animateur set cout_heure= result
      where current of c_ani;
    dbms_output.put (v_ani.no_anim||','||v_ani.fonction||','||taux||',');
    dbms_output.put_line (nb_atel||','||nb_anim||','||v_ani.cout_heure||','||result);
  end loop;
  commit;
end;
/

  