 set serveroutput on
declare
  type tintitule is table of atelier.intitule%type
    index by binary_integer;
  type tinscrit is table of number
    index by binary_integer;
  inscrits tinscrit;
  intitules tintitule;
begin
  select intitule,count(*) bulk collect into intitules,inscrits
      from inscription s,atelier t
      where s.no_atel=t.no_atel
      group by intitule;
for i in intitules.first..intitules.last loop
      dbms_output.put_line (rpad(intitules(i),35,'.')||inscrits(i));
end loop;
end;
/
