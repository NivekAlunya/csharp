create sequence s_stat_ate;
create table stat_ate (
no_oper number(6) constraint stat_ate_pk primary key,
no_atel number(4),
commande char(6),
date_oper date,
utilisateur varchar2(30));
create or replace trigger tr_a_oper_ate
  after insert or update or delete
  on atelier
  for each row
declare
  vOper stat_ate.commande%type;
  vNo_atel stat_ate.no_atel%type;
begin
  if inserting then
    vOper := 'INSERT';
    vNo_atel := :new.no_atel;
  elsif updating then
    vOper := 'UPDATE';
    vNo_atel := :old.no_atel;
  else
    vOper := 'DELETE';
    vNo_atel := :old.no_atel;
  end if;
  insert into stat_ate values
    (s_stat_ate.nextval,vNo_atel,vOper,sysdate,user);
end;
/
