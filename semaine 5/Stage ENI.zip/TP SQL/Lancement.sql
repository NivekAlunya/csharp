rem suppression des tables
rem
@@drop_table.sql
rem
rem cr�ation des tables
@@create_table.sql
rem
rem insertion des donn�es
rem
@@adherent.sql
@@animateur.sql
@@atelier.sql
@@activite.sql
@@inscription.sql
