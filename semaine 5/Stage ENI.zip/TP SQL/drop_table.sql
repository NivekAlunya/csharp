drop table INSCRIPTION;
drop table ACTIVITE;
drop table ATELIER;
drop table ANIMATEUR;
drop table ADHERENT;
